import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import {User} from 'src/app/models/User'
import { message } from '../models/message';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  loginOk:Boolean;
  p: number = 1;
  reply:Boolean;
  username:String;
  password:String;
  public testUsr:User;
  ShowMessages:Boolean;
  show:Boolean;
  messages:message[];
  constructor(private http:UserService) { }

  ngOnInit(): void {
    this.loginOk=false;
    this.ShowMessages=false;
   
  }
  handleClick():void{
    this.http.getUser(this.username).subscribe(
      data=>{
          this.testUsr=data;
          if(data.userName && data.password==this.password)
            localStorage.setItem("token",this.testUsr.userName.toString());
          else{
            this.http.setAuthenticatedFalse();
          }
      }
      );
    if(this.testUsr==null)
     { 
      this.http.setAuthenticatedFalse();
       document.getElementById("result").innerHTML="Sorry there is no username "+this.username;
       this.show=false;
     }
    else if(this.testUsr.password!=this.password)
     { 
      this.http.setAuthenticatedFalse();
       document.getElementById("result").innerHTML="Sory your password is incorect";
       this.show=false;
        
     }
    else 
    {
      this.http.setAuthenticatedTrue();
      document.getElementById("result").innerHTML="Welcome "+this.username;
      this.show=true;
      this.loginOk=true;
    }
  }
  seeMessages(){
    this.http.getMessages(this.username).subscribe(
      data=>{
        this.messages=data;
        this.ShowMessages=true;
      }
    );
  }
  Reply(){
    this.reply=true;
  }
  Search():void
  {}
  reset(){
    this.reply=false;
  }
}
