import { Component, OnInit, Input } from '@angular/core';
import { User } from '../models/User';
import {UserComponent} from 'src/app/user/user.component'
import { UserService } from '../user.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
 
  usr:User;
  changePs:Boolean;
  changeE:Boolean;
  newpassword:String="";
  newpassword2:String="";
  oldpassword:String="";
  newEmail:String="";  
  constructor(private http:UserService) { }

  ngOnInit(): void {
    this.usr=this.http.getLastUsr();
    this.changePs=false;
  }
  setPs(){
    this.changePs=true;
  }
  setE(){
    this.changeE=true;
  }
  changePsw()
  {
    if(this.newpassword!=this.newpassword2){
      document.getElementById("loginResult").innerHTML="Error passwords don't match";
      return;}
    if(!this.http.changePassword(this.usr,this.oldpassword,this.newpassword))
      document.getElementById("loginResult").innerHTML="Sorry wrong Password";
    else
       document.getElementById("loginResult").innerHTML="change of password succefull";
  }
  changeEmail()
  {
    if(this.oldpassword!=this.usr.password)
      document.getElementById("EmailResult").innerHTML="Sorry your password is incorrect"
    else{
      this.http.changeEmail(this.usr,this.newEmail);
      document.getElementById("EmailResult").innerHTML="Your new email adress is set to "+this.newEmail;
 }
  }
  changeNum()
  {

  }
  

}
