import { Component, OnInit } from '@angular/core';
import {User} from 'src/app/models/user'
import {UserService} from 'src/app/user.service'
import { AppartmentService } from '../appartment.service';
import {appartment} from 'src/app/models/appartment';
import { Observable } from 'rxjs';
import { review } from '../models/review';

@Component({
  selector: 'app-appartment',
  templateUrl: './appartment.component.html',
  styleUrls: ['./appartment.component.css']
})
export class AppartmentComponent implements OnInit {

  p: number = 1;
  usr:User;
  Country:String="";
  neighborhood:String="";
  City:String="";
  location:String="neighborhood-city-country";
  wifi:Boolean;
  pets:Boolean;
  parking:Boolean;
  ac:Boolean;
  smoking:Boolean;
  tv:Boolean;
  elevator:Boolean;
  allApartments:appartment[];
  input1:Observable<appartment[]>;
  show:Boolean;
  startD:String;
  endD:String;
  collection=[];
  capacity:number;

  constructor(private userhttp:UserService,private apphttp:AppartmentService) {
    //this.apphttp.getAllAppartments().subscribe(data => this.allApartments=data);
   }

  ngOnInit(): void {
    this.usr=this.userhttp.getLastUsr();
    /*this.input1=this.apphttp.getAllAppartments();
    this.input1.subscribe(data =>{ this.allApartments=data;
      console.log(this.allApartments)}
      );*/
    //console.log(this.allApartments);
    this.show=false;
    //this.capacity=5;
  }
  byLocation():void{
    var splitted=this.location.split("-");
    this.neighborhood=splitted[0];
    this.City=splitted[1];
    this.Country=splitted[2];    
    this.input1=this.apphttp.getAppartmentsBylocation(this.Country,this.City,this.neighborhood,this.startD,this.endD,this.capacity);
    this.input1.subscribe(
      data => 
      {
        this.allApartments=data;
        console.log(this.allApartments);
      }
    );
    this.show=true;
    ///aditional constraints from check boxes
    if(this.wifi==true){
      for(let i=0;i<this.allApartments.length;i++)
         if(!this.allApartments[i].hasWifi)
            delete this.allApartments[i];
    }
    if(this.tv==true){
      for(let i=0;i<this.allApartments.length;i++)
         if(!this.allApartments[i].hasTv)
            delete this.allApartments[i];
    }
    if(this.ac==true){
      for(let i=0;i<this.allApartments.length;i++)
         if(!this.allApartments[i].hasheat)
            delete this.allApartments[i];
    }
    if(this.pets)
      for(let i=0;i<this.allApartments.length;i++)
        if(!this.allApartments[i].allowPets)
          delete this.allApartments[i];
    if(this.smoking)
      for(let i=0;i<this.allApartments.length;i++)
        if(!this.allApartments[i].allowSmoking)
           delete this.allApartments[i];
    if(this.parking)
      for(let i=0;i<this.allApartments.length;i++)
        if(!this.allApartments[i].hasParking)
          delete this.allApartments[i];
    if(this.elevator)
      for(let i=0;i<this.allApartments.length;i++)
        if(!this.allApartments[i].hasElevator && this.allApartments[i].floor>=1)
            delete this.allApartments[i];
    for(let i=0;i<this.allApartments.length;i++){
      this.apphttp.getReviews(this.allApartments[i].id).subscribe(
        data=>this.allApartments[i].reviews=data
      );
    }
  }
  getAverage(array: review[]):number{
    var average:number=0;
    for(let i=0;i<array.length;i++){
     average+=array[i].number;
    }
    average=average/array.length;
    if(isNaN(average))
      return 0;
    return average;
  }

}
