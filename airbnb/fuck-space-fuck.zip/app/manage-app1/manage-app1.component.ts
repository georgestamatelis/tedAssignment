import { Component, OnInit } from '@angular/core';
import { AppartmentService } from '../appartment.service';
import { appartment } from '../models/appartment';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-manage-app1',
  templateUrl: './manage-app1.component.html',
  styleUrls: ['./manage-app1.component.css']
})
export class ManageApp1Component implements OnInit {

  cur:appartment;
  constructor(private route :ActivatedRoute ,private appHttp:AppartmentService) { }

  ngOnInit(): void {
    this.cur=new appartment;
    this.appHttp.getAppartmentById(+this.route.snapshot.queryParamMap.get("id")).subscribe(
      data=>this.cur=data
    );
  }
  

}
