import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnonymousComponent } from './anonymous/anonymous.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { SingupComponent } from './singup/singup.component';
import { AppartmentDetailsComponent } from './appartment-details/appartment-details.component';
import { AuthGuard } from './auth.guard';
import { ManageAppartmentsComponent } from './manage-appartments/manage-appartments.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { AdminGuard } from './admin.guard';
import { AddAppartmentComponent } from './add-appartment/add-appartment.component';
import { ManageApp1Component } from './manage-app1/manage-app1.component';


const routes: Routes = [
  {path:"anon", component:AnonymousComponent},
  {path:"admin",component:AdminComponent},
  {path:"user",component:UserComponent},
  {path:'manageApp1/:id',component:ManageApp1Component,canActivate:[AuthGuard]}/*later change it*/,
  {path:"add-appartment/:userName",component:AddAppartmentComponent,canActivate:[AuthGuard]},
  {path:"userDetails/:userName",component:UserDetailsComponent,canActivate:[AdminGuard]},
  {path:"signUp",component:SingupComponent},
  {path:"manageApp",component:ManageAppartmentsComponent, canActivate:[AuthGuard]},
  {path:"appDetails/:id/:startD/:endD",component:AppartmentDetailsComponent},
  { path:'editProfile', loadChildren: () => import('./edit-profile/edit-profile.module').then(m => m.EditProfileModule) ,canActivate:[AuthGuard] },
  { path: 'appartment', loadChildren: () => import('./appartment/appartment.module').then(m => m.AppartmentModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
