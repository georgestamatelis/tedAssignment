import { Component, OnInit } from '@angular/core';
import {User} from "src/app/models/User";
import { UserService } from '../user.service';
import { Observable } from 'rxjs';
import {appartment} from 'src/app/models/appartment';
import { Router } from '@angular/router';
import { AppartmentService } from '../appartment.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  adminame:String="";
  password:String="";
  loginOk:Boolean;
  ShowUsers:Boolean;
  ShowRequests:Boolean;
  userList :User[];
  input1:Observable<User[]>;
  appartmentList:appartment[];

  constructor(private httpUsr:UserService,private router:Router,private httpApp:AppartmentService) { }

  ngOnInit(): void {
    this.loginOk=false;
    this.ShowUsers=this.ShowRequests=false;
  }
  handleClick():void
  {
    if(this.adminame!="admin1" || this.password!="123")
    {
      document.getElementById("result").innerHTML="SORRY WRONG USERNAME OR PASSWORD";
      this.loginOk=false;
    }
    else{
      localStorage.setItem('admin-token','admin1');
      this.httpUsr.authAdmin();
      document.getElementById("result").innerHTML="LOGIN SUCCESFULL AVAILABLE OPTIONS :";      this.loginOk=true;
    }
  }
  displayUser(id:string,current:User):void{
    document.getElementById(id).innerHTML+="Username "+current.userName.toString()+"\n"; 
  }
  getAllUsers():void
  {
    if(this.loginOk==true)
     { 
       this.ShowUsers=true; 
       this.ShowRequests=false;
     }
    this.input1=this.httpUsr.getAllUsers();
    this.input1.subscribe( data=> this.userList=data); 
 //   for(let i=0;i<this.userList.length; i++)   
   //   this.displayUser("httpResult",this.userList[i]); 
      
  }
  getAllRequestingUsers():void
  {
    if(this.loginOk==true)
     {
       localStorage.setItem('admin-token','admin1');
        this.ShowRequests=true;
        this.ShowUsers=false; 
     }
    this.input1=this.httpUsr.getAllRequestingUsers();
    this.input1.subscribe( data=> this.userList=data);         
  }
  confirmRequest(username:string):void
  {
    if(!this.loginOk)
      return;
    this.httpUsr.confirmRequest(username);

  }
  logout(){
    localStorage.removeItem('admin-token');
    this.httpUsr.XauthAdmin();
    this.router.navigateByUrl("/");
  }

}
