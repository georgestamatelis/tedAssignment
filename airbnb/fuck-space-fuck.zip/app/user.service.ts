import { Injectable } from '@angular/core';
import {User} from 'src/app/models/User'
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { message } from './models/message';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  tester:User; 
  authenicated:Boolean=false; 
  adminAccess:Boolean=false;
  allUsers: String="https://localhost:8443/demo/admin?adminUSN=admin1&adminPSW=123";
  constructor(private http: HttpClient) { }
  authAdmin(){
    this.adminAccess=true;
  }
  XauthAdmin(){
    this.adminAccess=false;
  //  localStorage.removeItem()
  }
  setAuthenticatedTrue(){
    this.authenicated=true;
  }
  setAuthenticatedFalse(){
    this.authenicated=false;
  }
  isAuthenticated(){
    return this.authenicated;
  }
  getLastUsr():User
  {
    return this.tester;
  }
  getUser(usn:String) :Observable<User>
  {
    let url="https://localhost:8443/demo/oneUser/?username="+usn;
    this.http.get<User>(url).subscribe(data=>this.tester=data);
    return this.http.get<User>(url);
  }
  getAllUsers() :Observable<User[]>
  {
    return this.http.get<User[]>(this.allUsers.toString());
  }
  getAllRequestingUsers(): Observable<User[]>
  {
    return this.http.get<User[]>("https://localhost:8443/demo/admin/GetAllRequests");
  }
  confirmRequest(username:String): void {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
      })
    };
    
    let tempUrl="https://localhost:8443/demo/admin/ConfirmRequest";
    console.log(username);
    let body={
      "username":username
    }
    let subscription="";
    this.http.post<String>(tempUrl,body,httpOptions).subscribe(result=> subscription=result.toString());
  }
  //////////////////////////////////////////////////
  newUser(usr :User): Boolean{
    const httpOptions = {
      headers: { 'Content-Type': 'application/json'},    
    };
    let tempUrl="https://localhost:8443/demo/newUser";
    let subscription="";
    let body={
      "username":usr.userName,
      "password":usr.password,
      "email":usr.email,
       "phonenumber":usr.phoneNumber,
      "firstname":usr.firstName,
      "lastname":usr.lastName,
      "Request":"false"
  };
    if(usr.requestforOwner)
    {
      body={
        "username":usr.userName,
        "password":usr.password,
        "email":usr.email,
         "phonenumber":usr.phoneNumber,
        "firstname":usr.firstName,
        "lastname":usr.lastName,
         "Request":"true"}
    };
      
    this.getUser(usr.userName).subscribe(
      data=>this.tester=data
    );
   //console.log(this.tester.userName);
    if(this.tester!=null)
      return false;
    //console.log("fuck me");
    this.http.post<String>(tempUrl,body,httpOptions).subscribe(result=> subscription=result.toString());
    return true;
  }
  changePassword(usr :User,identifier:String,newPassword :String):Boolean{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
      })
    };
    if(usr.password != identifier)
      return false; //WRONG PASSWORD
    let tempUrl="https://localhost:8443/demo/EditUserData/Password";
    let subscription="";
    let body={
      "username":usr.userName,
      "newPassword":newPassword
    }
    this.http.put<String>(tempUrl,body,httpOptions).subscribe(result => subscription=result.toString());
    return true;
    
  }
  //////////////////////////////////////////
  changeEmail(usr:User, newEmail:String):Boolean
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
      })
    };
    let tempUrl="https://localhost:8443/demo/EditUserData/Email";
    let subscription="";
    let body={
      "username":usr.userName,
      "newEmail":newEmail
    }
    this.http.put<String>(tempUrl,body,httpOptions).subscribe(result => subscription=result.toString());
    return true;

  }
  loggedIn(){
    if(!this.authenicated)
      return false;
    return localStorage.getItem('token')==this.getLastUsr().userName ;
  }
  adminLoggedIn(){
    if(!this.adminAccess)
      return false;
    return !!localStorage.getItem("admin-token");
  }
  getToken(){
    return localStorage.getItem('token');
  }
  logout(){
    this.authenicated=false;
  }
  messageUsr(sender:String,receiver:String,date:String,text:String){
    let url="https://localhost:8443/accesories/messages/newMessage"
    let body={
      "receiver":receiver,
      "sender":sender,
      "date":date,
      "text":text
    };
    let subscription="";
    this.http.post<String>(url,body).subscribe(
      data=>subscription=data.toString()
    );
  }
  getMessages(usn:String):Observable<message[]>{
    let url="https://localhost:8443/accesories/messages/getAllByUsr/?receiver="+usn;
    console.log("fuck");
    return this.http.get<message[]>(url);
      
  }
}

