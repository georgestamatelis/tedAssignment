import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { AppartmentService } from '../appartment.service';
import { appartment } from '../models/appartment';
import { ActivatedRoute } from '@angular/router';
import{User} from 'src/app/models/User';

@Component({
  selector: 'app-add-appartment',
  templateUrl: './add-appartment.component.html',
  styleUrls: ['./add-appartment.component.css']
})
export class AddAppartmentComponent implements OnInit {

  tempApp:appartment;
  endD:String="";
  startD:String="";
  country:String="";
  city:String="";
  hood:String="";
  dates: String[];
  curentUser:User;
  psw:String;
  constructor(private route: ActivatedRoute,private userHttp:UserService,private appHttp:AppartmentService ) { }

  ngOnInit(): void {
    this.tempApp=new appartment;
    ///initializing all to false
    this.tempApp.hasTv=this.tempApp.hasWifi=this.tempApp.hasElevator=this.tempApp.hasParking=false;
    this.tempApp.hasheat=this.tempApp.idAvailable=this.tempApp.allowPets=false;
    //this.dates=new String[];
  }
  PostIt():void{
    
    let arr=this.route.snapshot.params.userName.split(":");
    this.tempApp.ownername=arr[1];
    console.log(arr[1]);
    this.userHttp.getUser(arr[1]).subscribe(
      data=>{
        this.curentUser=data;
        this.psw=data.password;}
    );
    var date:String=this.startD;
    this.dates=[this.startD,this.endD];
    this.tempApp.dates=this.dates;
    this.appHttp.postAppartment(this.tempApp,this.psw,this.city,this.country,this.hood);
  }
}
