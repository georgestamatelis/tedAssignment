import { Component, OnInit } from '@angular/core';
import{ User } from "src/app/models/User";
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  current:User;

  constructor(private route: ActivatedRoute,private userHttp:UserService) { }

  ngOnInit(): void {
    let arr=this.route.snapshot.params.userName.split(":");
    let userN=arr[1];
    this.userHttp.getUser(userN).subscribe(
      data=>{
          this.current=data;
          console.log(data);
      }
  );
  }
  confirmRequest(){
    this.userHttp.confirmRequest(this.current.userName);
  }

}
