export class review{
userName:String;
appId:Number;
comment:String;
number:number; 
}