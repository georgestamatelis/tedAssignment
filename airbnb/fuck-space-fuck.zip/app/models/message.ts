export class message{
    id:Number;
    senderUsn:String;
    receiverUsn:String;
    date:String;
    text:String
}