export class User{
    userName:String;
    password:String;
    email:String;
    firstName:String;
    lastName:String;
    phoneNumber:String;
    requestforOwner:Boolean;
    owner:Boolean;
    renter:Boolean;
}