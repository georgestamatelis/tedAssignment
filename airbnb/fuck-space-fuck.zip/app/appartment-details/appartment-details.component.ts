import { Component, OnInit, Input } from '@angular/core';
import { appartment } from '../models/appartment';
import { ActivatedRoute } from '@angular/router';
import { AppartmentService } from '../appartment.service';
import { UserService } from '../user.service';
import {User} from 'src/app/models/User';

declare var ol: any;

@Component({
  selector: 'app-appartment-details',
  templateUrl: './appartment-details.component.html',
  styleUrls: ['./appartment-details.component.css']
})

export class AppartmentDetailsComponent implements OnInit {

  //@Input()
  latitude: number = 18.5204;
  longitude: number = 73.8567;

  map: any;

  Question:String;
  openChat:Boolean;
  cur:appartment;
  id:String;
  id1:number;
  Dates:String[];
  review:number;
  usr:User; 
  //averageReview:number;
  constructor(private route: ActivatedRoute,private apphttp:AppartmentService,private userhttp:UserService) { }

  ngOnInit(): void {
   /* this.map = new ol.Map({
      target: 'map',
      layers: [
        new ol.layer.Tile({
          source: new ol.source.OSM()
        })
      ],
      view: new ol.View({
        center: ol.proj.fromLonLat([73.8567, 18.5204]),
        zoom: 8
      })
    });
*/
    /////////////////////////////////////////
    this.id=this.route.snapshot.params.id;
    console.log(this.id);
    var arr=this.id.split(":");
    this.id1=+arr[2];
    console.log(this.id1);
    this.apphttp.getAppartmentById(this.id1).subscribe(
      data=>{this.cur=data;
      console.log(this.cur);
      
    }
    );
  this.openChat=false;  
  let sd=this.route.snapshot.params.startD;
  arr=sd.split(":");
  let StartD=arr[2];
  console.log(StartD);
  let ed=this.route.snapshot.params.endD;
  arr=ed.split(":");
  let endD=arr[2];
  console.log(endD);
  this.Dates=[StartD,endD]; //for now
  }
  Book():void{
    if(this.userhttp.loggedIn())
      {
        document.getElementById("resUlt").innerHTML="Success";
        console.log(this.Dates);
        this.apphttp.bookAppartment(this.id1,this.Dates,this.userhttp.getLastUsr().userName);
      }
    else{
      window.alert("You must be logged in to make a purchase!");
     // this.route.navigateByUrl("/user");
    }

  }
  setCenter() {
    var view = this.map.getView();
    view.setCenter(ol.proj.fromLonLat([this.longitude, this.latitude]));
    view.setZoom(8);
  }
  message():void{
    if(this.userhttp.loggedIn())
      this.openChat=true;
    else
      window.alert("You must be logged in to send a message");
  }
  submit(){
    console.log(this.review);
    this.apphttp.addReview(this.userhttp.getLastUsr().userName,this.cur.id,this.review," ");
  }
  sendMessage(){
    this.usr=this.userhttp.getLastUsr();
    this.userhttp.messageUsr(this.usr.userName,this.cur.ownername,"2-2-2020",this.Question)
  }

}
